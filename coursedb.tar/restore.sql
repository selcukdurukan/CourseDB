--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE coursedb;
--
-- Name: coursedb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE coursedb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE coursedb OWNER TO postgres;

\connect coursedb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: student_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_classes (
    oid integer NOT NULL,
    national_id bigint NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    city character varying NOT NULL,
    street character varying NOT NULL,
    country character varying NOT NULL,
    country_code integer NOT NULL,
    course_id integer,
    course_name character varying,
    attandence_year integer,
    grade double precision
);


ALTER TABLE public.student_classes OWNER TO postgres;

--
-- Name: student_classes_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_classes_oid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_classes_oid_seq OWNER TO postgres;

--
-- Name: student_classes_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_classes_oid_seq OWNED BY public.student_classes.oid;


--
-- Name: telephone_numbers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telephone_numbers (
    student_oid integer NOT NULL,
    telephone_number bigint NOT NULL,
    type character varying NOT NULL
);


ALTER TABLE public.telephone_numbers OWNER TO postgres;

--
-- Name: telephone_numbers_student_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telephone_numbers_student_oid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telephone_numbers_student_oid_seq OWNER TO postgres;

--
-- Name: telephone_numbers_student_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telephone_numbers_student_oid_seq OWNED BY public.telephone_numbers.student_oid;


--
-- Name: student_classes oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes ALTER COLUMN oid SET DEFAULT nextval('public.student_classes_oid_seq'::regclass);


--
-- Name: telephone_numbers student_oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telephone_numbers ALTER COLUMN student_oid SET DEFAULT nextval('public.telephone_numbers_student_oid_seq'::regclass);


--
-- Data for Name: student_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_classes (oid, national_id, first_name, last_name, city, street, country, country_code, course_id, course_name, attandence_year, grade) FROM stdin;
\.
COPY public.student_classes (oid, national_id, first_name, last_name, city, street, country, country_code, course_id, course_name, attandence_year, grade) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: telephone_numbers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telephone_numbers (student_oid, telephone_number, type) FROM stdin;
\.
COPY public.telephone_numbers (student_oid, telephone_number, type) FROM '$$PATH$$/3328.dat';

--
-- Name: student_classes_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_classes_oid_seq', 1, true);


--
-- Name: telephone_numbers_student_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telephone_numbers_student_oid_seq', 1, false);


--
-- Name: student_classes student_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT student_classes_pkey PRIMARY KEY (oid);


--
-- Name: telephone_numbers telephone_numbers_student_oid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telephone_numbers
    ADD CONSTRAINT telephone_numbers_student_oid_fkey FOREIGN KEY (student_oid) REFERENCES public.student_classes(oid) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

